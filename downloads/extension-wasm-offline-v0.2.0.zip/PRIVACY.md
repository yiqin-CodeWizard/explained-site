# extension-wasm-offline — privacy (v0.2.0)

This variant uses official DeepSeek APIs with a key supplied by each user. The developer operates no lookup server. No DeepSeek website login, connection tab or proof-of-work module is used.

## What is sent

Selecting or copying alone sends nothing. Clicking the selection icon or pressing Ctrl+X (⌘X on Mac) on supported reading text sends the selected text (up to 500 characters) to DeepSeek. If enabled, up to 600 nearby characters provide context. Turning context off sends only the selection.

Ordinary explanations call the model API. News, time-sensitive selections and “Explain a little more” also call DeepSeek Search. Search evidence is passed to the model for summarization. News asks for developments from the past 30 days. Check displayed dates and original sources.

Welcome verifies the supplied key using DeepSeek's model-list API. Verification does not send reading text or create a paid model/search lookup. Subsequent API calls are billed to the user's DeepSeek account.

## What is stored

The API key, consent and preferences are saved in Chrome's local extension storage on this device, not Chrome sync. Local storage is restricted to trusted extension contexts. Reading-page content scripts obtain sanitized preferences through messages and cannot read the key. The key is attached only to background requests to https://api.deepseek.com. Local extension storage is not an encrypted secrets vault; someone with access to the browser profile/device may access it.

Answers and sources are held in memory for the current card and cleared on close/navigation. The developer stores no lookup history, reading text, analytics, advertising identifiers or credentials.

## Controls and permissions

Use Welcome/API settings to replace the key. Use the toolbar to pause globally, pause a site, or disable nearby context. Removing the extension removes its local storage. Restrict website access in Chrome if desired; reading-page access is required to obtain a selection, nearby text and show the answer card. The extension does not request clipboard access or intercept Cut in editors.

## External services

DeepSeek receives submitted text, search queries, authentication and ordinary network metadata, and handles these under its current terms and API policies. Original-source links open external websites when clicked. The optional practice article is on the public Explained website. Check DeepSeek's policies before submitting sensitive material. Removing this extension does not remove information retained by external services.

This policy applies to this variant's v0.2.0 API edition. Other variants and earlier versions may still use the website connection and their existing policies. The local privacy.html contains the corresponding readable disclosure; site builds must preserve this independent policy.
