# Official API edition validation

2026-10-27 · extension-wasm-offline v0.2.0

- 15 Node API/background tests pass: normal model-only requests, explicit search for more/time-sensitive/news requests, bounded Unicode queries, verified source mapping, invalid/empty evidence, 401/402/429/503, truncated/malformed/UTF-8 SSE, cancellation, private key persistence, sender boundaries, legacy migration and prompt redaction.
- The original edition's 25 contract/bridge/decoder tests pass. The independent API suite replaces the retired WASM-specific tests.
- A real temporary MV3 installation in Chromium completes Welcome using a synthetic key and model-list response, then runs explanation, fresh-search more, cached short, News, empty-search fallback/retry, request cancellation, Ctrl+X and native Cut in editors. Existing A/B/C layouts and context-off mode are exercised.
- A test-only isolated content script confirms local API key reads are denied and key storage changes are not exposed. No DeepSeek website tab is created, no unexpected external requests occur, and browser page errors are empty.
- Browser screenshots and machine-readable evidence are in validation/api under the project root. All remote API responses are controlled fixtures; no real account, key or paid API lookup is used.

Commands: `node --test tests/wasm-offline-api.test.cjs`, `node tests/wasm-offline-browser.cjs`, `python3 tools/package-wasm-offline.py`. The existing `EXPLAINED_EDITION=extension-wasm-offline node tests/ui.test.cjs` entry forwards to the real extension test.

These checks validate extension behavior and official documented request shapes. A user-supplied key is still required to verify real account availability, billing balance and live model/search responses. Chrome 114, long browser sleep/resume and store review are not established by this run.
